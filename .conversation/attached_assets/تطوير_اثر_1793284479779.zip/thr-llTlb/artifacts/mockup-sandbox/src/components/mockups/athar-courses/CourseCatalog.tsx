import { useMemo, useState } from "react";
import {
  ArrowDownLeft,
  ArrowUpLeft,
  BookOpen,
  Check,
  CheckCircle2,
  ChevronDown,
  Circle,
  FileText,
  Search,
  Sparkles,
} from "lucide-react";
import "./_group.css";
import "./course-catalog.css";

type Material = {
  type: "text" | "link" | "media";
  mediaType?: "image" | "video" | "file";
  title: string;
  body: string;
  url: string;
};

type Course = {
  title: string;
  description: string;
  materials: Material[];
};

const courses: Course[] = [
  {
    title: "كورس تحليل بيانات",
    description: "كورس تحليل بيانات",
    materials: [
      {
        type: "text",
        title: "مقدمة في تحليل البيانات",
        body: "ابدأ بالتعرّف إلى خطوات فهم البيانات وتنظيمها.",
        url: "",
      },
    ],
  },
  {
    title: "كورس تحليل بيانات",
    description: "كورس تحليل بيانات",
    materials: [
      {
        type: "text",
        title: "تطبيق عملي",
        body: "تدرّب على قراءة البيانات واستخلاص فكرة واضحة منها.",
        url: "",
      },
    ],
  },
];

type Filter = "all" | "open" | "completed";

export function CourseCatalog() {
  const [completion, setCompletion] = useState<Record<number, boolean>>({});
  const [expanded, setExpanded] = useState<Record<number, boolean>>({});
  const [filter, setFilter] = useState<Filter>("all");
  const [search, setSearch] = useState("");
  const [notice, setNotice] = useState("");

  const visibleCourses = useMemo(() => courses
    .map((course, index) => ({ course, index }))
    .filter(({ course, index }) => {
      const matchesFilter = filter === "all"
        || (filter === "completed" && completion[index])
        || (filter === "open" && !completion[index]);
      const query = search.trim();
      return matchesFilter && (!query || `${course.title} ${course.description}`.includes(query));
    }), [completion, filter, search]);

  const completedCount = Object.values(completion).filter(Boolean).length;

  const toggleCompletion = (index: number) => {
    const willComplete = !completion[index];
    setCompletion(current => ({ ...current, [index]: willComplete }));
    setNotice(willComplete ? "سُجّل إنجازك في سجلّ التعلّم." : "تم تحديث حالة الدورة.");
  };

  return (
    <main className="athar-course-preview dark cc-page" dir="rtl">
      <div className="cc-shell">
        <nav className="cc-breadcrumb" aria-label="مسار الصفحة">
          <span>مساحة الطالب</span>
          <ArrowDownLeft size={14} aria-hidden="true" />
          <span className="cc-current">كورساتي</span>
        </nav>

        <header className="cc-hero">
          <div className="cc-hero-orbit" aria-hidden="true">
            <span className="cc-orbit-dot" />
            <BookOpen size={31} strokeWidth={1.5} />
          </div>
          <div className="cc-hero-copy">
            <span className="cc-eyebrow"><Sparkles size={14} /> مساحة تعلّمك</span>
            <h1>كورساتي</h1>
            <p>تعلّم على مهل، وسجّل ما أنجزته بثقة.</p>
          </div>
          <div className="cc-hero-foot">
            <span>إنجازك يُحفظ هنا</span>
            <span className="cc-completion-mark"><Check size={13} /></span>
          </div>
        </header>

        <section className="cc-catalog" aria-labelledby="cc-title">
          <div className="cc-section-heading">
            <div>
              <span className="cc-section-label">مسارك الدراسي</span>
              <h2 id="cc-title">الدورات</h2>
              <p>افتح المواد، ثم سجّل ما أتممته في سجلّ تعلّمك.</p>
            </div>
            <div className="cc-completion-summary" aria-label={`الدورات المكتملة: ${completedCount}`}>
              <span>{String(completedCount).padStart(2, "0")}</span>
              <small>مكتملة</small>
            </div>
          </div>

          <div className="cc-tools">
            <label className="cc-search">
              <Search size={17} aria-hidden="true" />
              <input
                type="search"
                value={search}
                onChange={event => setSearch(event.target.value)}
                placeholder="ابحث في دوراتك"
                aria-label="ابحث في دوراتك"
              />
              {search && <button type="button" onClick={() => setSearch("")} aria-label="مسح البحث">×</button>}
            </label>
            <div className="cc-filter" role="group" aria-label="تصفية الدورات">
              {([
                ["all", "الكل"],
                ["open", "قيد التعلّم"],
                ["completed", "مكتملة"],
              ] as [Filter, string][]).map(([value, label]) => (
                <button
                  key={value}
                  type="button"
                  className={filter === value ? "is-active" : ""}
                  aria-pressed={filter === value}
                  onClick={() => setFilter(value)}
                >
                  {label}
                </button>
              ))}
            </div>
          </div>

          {notice && <p className="cc-notice" role="status"><CheckCircle2 size={16} />{notice}</p>}

          {visibleCourses.length ? (
            <div className="cc-course-list">
              {visibleCourses.map(({ course, index }) => {
                const isCompleted = Boolean(completion[index]);
                const isExpanded = Boolean(expanded[index]);
                return (
                  <article className={`cc-course-card ${isCompleted ? "is-completed" : ""}`} key={index}>
                    <div className="cc-card-topline">
                      <span className="cc-course-index">{String(index + 1).padStart(2, "0")}</span>
                      <span className="cc-course-context">دورة تعلّم</span>
                      {isCompleted && <span className="cc-status"><Check size={13} /> مكتملة</span>}
                    </div>
                    <div className="cc-course-copy">
                      <h3>{course.title}</h3>
                      <p>{course.description}</p>
                    </div>
                    <button
                      type="button"
                      className="cc-material-toggle"
                      aria-expanded={isExpanded}
                      onClick={() => setExpanded(current => ({ ...current, [index]: !current[index] }))}
                    >
                      <span className="cc-toggle-icon"><FileText size={16} /></span>
                      <span className="cc-toggle-copy">
                        <b>{isExpanded ? "إخفاء المواد" : "استكشف مواد الدورة"}</b>
                        <small>{course.materials.length.toLocaleString("ar")} {course.materials.length === 1 ? "مادة" : "مواد"}</small>
                      </span>
                      {isExpanded ? <ArrowUpLeft size={17} /> : <ChevronDown size={17} />}
                    </button>
                    {isExpanded && (
                      <div className="cc-materials">
                        {course.materials.map((material, materialIndex) => (
                          <section className="cc-material" key={`${index}-${materialIndex}`}>
                            <span className="cc-material-icon"><BookOpen size={17} /></span>
                            <div>
                              <h4>{material.title}</h4>
                              {material.body && <p>{material.body}</p>}
                            </div>
                          </section>
                        ))}
                      </div>
                    )}
                    <footer className="cc-card-footer">
                      {isCompleted ? (
                        <>
                          <span className="cc-recorded"><CheckCircle2 size={17} /> أُضيفت إلى سجلّ تعلّمك</span>
                          <button type="button" className="cc-undo" onClick={() => toggleCompletion(index)}>تراجع</button>
                        </>
                      ) : (
                        <button type="button" className="cc-complete" onClick={() => toggleCompletion(index)}>
                          <Circle size={17} />
                          سجّل إكمال الدورة
                        </button>
                      )}
                    </footer>
                  </article>
                );
              })}
            </div>
          ) : (
            <div className="cc-empty">
              <span className="cc-empty-icon"><Search size={21} /></span>
              <h3>لا توجد دورات هنا</h3>
              <p>{search ? "جرّب عبارة بحث أخرى أو غيّر التصفية." : "لا توجد دورات مطابقة لهذا الاختيار."}</p>
              <button type="button" onClick={() => { setSearch(""); setFilter("all"); }}>عرض كل الدورات</button>
            </div>
          )}
        </section>

        <footer className="cc-page-foot">
          <span className="cc-foot-line" />
          <p>خطوة صغيرة تُسجّل، وأثرها يبقى.</p>
          <span className="cc-foot-line" />
        </footer>
      </div>
    </main>
  );
}
