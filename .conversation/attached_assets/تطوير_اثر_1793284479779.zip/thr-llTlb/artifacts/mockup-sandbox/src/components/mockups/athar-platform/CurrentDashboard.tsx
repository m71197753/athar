import { useState, type CSSProperties, type ReactNode } from 'react';
import {
  ArrowLeft, Award, BookMarked, BookOpen, BriefcaseBusiness, ClipboardList, FileText,
  GraduationCap, HeartHandshake, Lightbulb, LogOut, Menu, MessageCircle, Moon,
  Plus, Route as RouteIcon, Sparkles, Sun, Target, TrendingUp,
} from 'lucide-react';
import './_group.css';
import './visual-refresh.css';

type DemoAchievement = {
  id: string;
  category: string;
  achievedOn: string;
  title: string;
  summary?: string;
  resumeBullet?: string;
  result?: string;
  skills: string[];
};

const demoSummary = {
  totalAchievements: 0,
  achievementsThisMonth: 0,
  readinessScore: 0,
  points: 0,
  completedCourses: 0,
  completedLessons: 0,
  profileCompletion: 0,
  recentAchievements: [] as DemoAchievement[],
};

const demoProfile: { fullName: string } | null = null;
const categoryNames: Record<string, string> = {
  project: 'مشروع', internship: 'تدريب', volunteer: 'تطوع', competition: 'مسابقة',
  course: 'دورة', research: 'بحث', other: 'أخرى',
};
const categoryIcons: Record<string, typeof ClipboardList> = {
  project: BriefcaseBusiness, internship: GraduationCap, volunteer: HeartHandshake,
  competition: Award, course: BookOpen, research: Lightbulb, other: ClipboardList,
};

function InertLink({ href, children, ...props }: React.AnchorHTMLAttributes<HTMLAnchorElement>) {
  return <a href={href} {...props} onClick={(event) => event.preventDefault()}>{children}</a>;
}

function Brand({ small = false }: { small?: boolean }) {
  return <span className={`brand-lockup ${small ? 'brand-small' : ''}`}><img className="brand-image" src="/__mockup/athar-wordmark.png" alt="أثر" data-testid="img-brand-logo" /></span>;
}

function ThemeToggle({ onToggle, isDark }: { onToggle: () => void; isDark: boolean }) {
  return <button type="button" className="theme-toggle" onClick={onToggle} aria-label={isDark ? 'تفعيل الوضع الفاتح' : 'تفعيل الوضع الداكن'} aria-pressed={isDark} data-testid="button-theme-toggle">
    {isDark ? <Sun size={18} aria-hidden="true"/> : <Moon size={18} aria-hidden="true"/>}
  </button>;
}

function Shell({ children: content, isDark, toggleTheme }: { children: ReactNode; isDark: boolean; toggleTheme: () => void }) {
  const [menuOpen, setMenuOpen] = useState(false);
  const navItems = [
    { href: '/dashboard', label: 'الرئيسية', icon: Target },
    { href: '/profile', label: 'ملفي الشخصي', icon: GraduationCap },
  ];
  const mobileItems = [
    { href: '/dashboard', label: 'الرئيسية', icon: Target },
    { href: '/achievements', label: 'إنجازاتي', icon: Award },
    { href: '/resume', label: 'سيرتي المهنية', icon: FileText },
    { href: '/profile', label: 'ملفي الشخصي', icon: GraduationCap },
  ];
  const loc = '/dashboard';
  const firstName = demoProfile?.fullName.slice(0, 1) || 'ط';
  const displayName = demoProfile?.fullName || 'طالب أثر';
  return <div className="app-frame" dir="rtl">
    {menuOpen && <button className="mobile-scrim" aria-label="إغلاق القائمة" onClick={() => setMenuOpen(false)} data-testid="button-close-menu"/>}
    <aside className={`sidebar ${menuOpen ? 'sidebar-open' : ''}`}>
      <InertLink href="/dashboard" className="side-brand" data-testid="link-sidebar-brand"><Brand/></InertLink>
      <div className="side-caption">مساحة الطالب</div>
      <nav className="side-nav">{navItems.map(item => {
        const Icon = item.icon;
        const active = loc === item.href || (item.href === '/academy' && loc.startsWith('/academy/'));
        return <InertLink key={item.href} href={item.href} onClick={() => setMenuOpen(false)} className={`side-link ${active ? 'side-link-active' : ''}`} data-testid={`link-nav-${item.href.slice(1)}`}><Icon size={19}/><span>{item.label}</span>{active && <span className="nav-current"/>}</InertLink>;
      })}</nav>
      <div className="side-grow"/>
      <div className="side-help"><div className="help-icon"><img src="/__mockup/athar-icon.png" alt="" width={20} height={20}/></div><b>خطوة بخطوة</b><p>دوّن ما تعلّمته اليوم، واجعل كل خطوة واضحة في مسارك.</p></div>
      <div className="sidebar-status"><span className="status-indicator"/>{'المساحة تعمل'}</div>
      <div className="side-user"><span className="user-avatar">{firstName}</span><span className="user-meta"><b>{displayName}</b><small>مساحتك الشخصية</small></span><button type="button" className="icon-button logout-button" aria-label="تسجيل الخروج" data-testid="button-sign-out"><LogOut size={17}/></button></div>
    </aside>
    <div className="main-column"><header className="topbar"><button className="mobile-menu-button" type="button" onClick={() => setMenuOpen(true)} aria-label="فتح القائمة" data-testid="button-open-menu"><Menu size={20}/></button><InertLink href="/dashboard" className="mobile-header-brand" data-testid="link-mobile-header-brand"><Brand small/></InertLink><span className="topbar-crumb">مساحة الطالب <span>/</span> {navItems.find(item => item.href === loc)?.label || 'أثر'}</span><ThemeToggle isDark={isDark} onToggle={toggleTheme}/><div className="topbar-right"><span className="topbar-note">وثّق ما تعلّمته اليوم</span><span className="avatar-mini">{firstName}</span></div></header><main className="content-area">{content}</main><footer className="app-footer"><span>أثر — تجاربك الجامعية في مكان واحد</span><InertLink href="/privacy" className="text-link">الخصوصية</InertLink><span className="footer-health"><span className="status-indicator"/>{'الاتصال مستقر'}</span></footer></div>
    <nav className="mobile-bottom-nav" aria-label="التنقل السريع">
      {mobileItems.slice(0, 2).map(item => { const Icon = item.icon; const label = item.href === '/achievements' ? 'الأثر' : item.label; return <InertLink key={item.href} href={item.href} className={`mobile-bottom-link ${loc === item.href ? 'mobile-bottom-active' : ''}`} data-testid={`mobile-nav-${item.href.slice(1)}`}><Icon size={18}/><span>{label}</span></InertLink>; })}
      <button className="mobile-create-button" type="button" aria-label="وثّق أثراً جديداً" data-testid="mobile-nav-create"><Plus size={21}/></button>
      {mobileItems.slice(2).map(item => { const Icon = item.icon; const label = item.href === '/resume' ? 'سيرتي' : 'ملفي'; return <InertLink key={item.href} href={item.href} className={`mobile-bottom-link ${loc === item.href ? 'mobile-bottom-active' : ''}`} data-testid={`mobile-nav-${item.href.slice(1)}`}><Icon size={18}/><span>{label}</span></InertLink>; })}
    </nav>
  </div>;
}

function PageTitle({ kicker, title, detail, action }: { kicker: string; title: string; detail: string; action?: React.ReactNode }) {
  return <><div className="page-title"><div><span className="page-kicker">{kicker}</span><h1>{title}</h1><p>{detail}</p></div>{action && <div className="page-title-action">{action}</div>}</div></>;
}

function ProgressRing({ value, label }: { value: number; label: string }) {
  return <div className="progress-ring-wrap"><div className="progress-ring" style={{ '--progress': `${Math.max(0, Math.min(100, value))}%` } as CSSProperties}><div className="progress-ring-inner"><b>{value}<small>%</small></b></div></div><span>{label}</span></div>;
}

function AchievementCard({ item, compact = false }: { item: typeof demoSummary.recentAchievements[number]; compact?: boolean }) {
  const Icon = categoryIcons[item.category] || ClipboardList;
  return <article className={`achievement-card ${compact ? 'achievement-compact' : ''}`} data-testid={`card-achievement-${item.id}`}>
    <div className="achievement-icon"><Icon size={19}/></div>
    <div className="achievement-content"><div className="achievement-topline"><span className="achievement-category">{categoryNames[item.category] || 'إنجاز'}</span><time>{new Date(item.achievedOn).toLocaleDateString('ar', { year: 'numeric', month: 'short' })}</time></div><h3 data-testid={`text-achievement-title-${item.id}`}>{item.title}</h3><p>{item.summary || item.resumeBullet || item.result}</p><div className="skill-list">{item.skills?.slice(0, 4).map(skill => <span className="skill-pill" key={skill}>{skill}</span>)}</div></div>
  </article>;
}

function DashboardPage() {
  const data = demoSummary;
  const firstName = demoProfile?.fullName.trim().split(/\s+/)[0];
  const greeting = firstName ? `أهلاً ${firstName}،` : 'أهلاً بك في أثر';
  const readiness = data.readinessScore ?? 0;
  const recent = data.recentAchievements || [];
  const features = [
    { href: '/achievements', title: 'إنجازاتي', description: 'تابع تقدمك، واستعرض إنجازاتك، واكتشف مدى تطورك.', action: 'عرض إنجازاتي', icon: Award, tone: 'amber' },
    { href: '/learning', title: 'تعلّمي', description: 'تابع مسارك التعليمي، واستكمل رحلتك نحو اكتساب معرفة جديدة.', action: 'متابعة التعلم', icon: BookOpen, tone: 'indigo' },
    { href: '/academy', title: 'المذاكرة', description: 'نظّم جلسات مذاكرتك، وراجع دروسك، وحافظ على استمرارية تقدمك.', action: 'ابدأ المذاكرة', icon: BookMarked, tone: 'violet' },
    { href: '/languages/study', title: 'تعلّم اللغات', description: 'طوّر مهاراتك اللغوية، ووسّع آفاقك، وتقدم خطوة جديدة كل يوم.', action: 'استكشف اللغات', icon: MessageCircle, tone: 'teal' },
    { href: '/roadmap', title: 'خطتي المهنية', description: 'حدّد أهدافك المهنية، وطوّر مهاراتك، وخطّط لخطوتك القادمة.', action: 'عرض خطتي', icon: RouteIcon, tone: 'blue' },
    { href: '/resume', title: 'سيرتي المهنية', description: 'أنشئ سيرتك المهنية، ونظّم خبراتك ومهاراتك، واستعد لفرص جديدة.', action: 'إدارة سيرتي', icon: FileText, tone: 'green' },
    { href: '/assistant', title: 'المساعد الذكي', description: 'احصل على المساعدة في التعلّم، والتخطيط، والكتابة، وإنجاز مهامك.', action: 'ابدأ المحادثة', icon: Sparkles, tone: 'purple' },
  ];
  const stats = [
    { value: data.totalAchievements, label: 'إنجاز موثّق', icon: Award, testId: 'text-total-achievements' },
    { value: data.achievementsThisMonth, label: 'إنجاز هذا الشهر', icon: TrendingUp, testId: 'text-month-achievements' },
    { value: data.completedCourses, label: 'دورة مكتملة', icon: BookOpen, testId: 'text-completed-courses' },
    { value: data.completedLessons, label: 'درس مكتمل', icon: GraduationCap, testId: 'text-completed-lessons' },
    { value: data.points, label: 'نقطة نمو', icon: Sparkles, testId: 'text-dashboard-points' },
    { value: readiness, label: 'الجاهزية المهنية', icon: Target, testId: 'text-readiness-score', suffix: '%' },
  ].filter(stat => stat.value > 0);
  return <div className="page-wrap">
     <PageTitle kicker="مساحتك اليوم" title={greeting} detail="مساحتك الشخصية للتعلّم، وتطوير مهاراتك، وتحقيق أهدافك." action={<button className="button button-primary" data-testid="button-add-from-dashboard"><Plus size={17}/> وثّق تجربة</button>}/>
     <section className="welcome-strip dashboard-welcome" data-testid="dashboard-welcome">
       <div className="welcome-copy"><span className="welcome-overline">خطوتك التالية</span><h2>ابدأ من هنا<br/><em>واختر مساحتك</em></h2><p>تعلّم، وثّق ما أنجزته، وخطّط لخطوتك المهنية القادمة من المكان نفسه.</p></div>
       <InertLink href="/academy" className="dashboard-start" data-testid="link-dashboard-start"><span className="dashboard-start-icon"><GraduationCap size={22}/></span><span><b>ابدأ رحلتك في أثر</b><small>استكشف مساحة التعلّم وابدأ من هنا</small></span><ArrowLeft size={18}/></InertLink>
       <div className="welcome-index">مساحة الطالب</div>
     </section>
     <section className="dashboard-tools" aria-labelledby="dashboard-tools-title">
       <div className="dashboard-section-heading"><div><span className="section-kicker">اكتشف مساحتك</span><h2 id="dashboard-tools-title">مساحتك في أثر</h2><p>كل أدواتك للتعلّم والتطوير في مكان واحد</p></div></div>
       <div className="dashboard-feature-grid">{features.map(({ href, title, description, action, icon: Icon, tone }) => <InertLink key={href} href={href} className={`dashboard-feature-card feature-${tone}`} data-testid={`dashboard-feature-${href.slice(1).replaceAll('/', '-')}`}>
         <span className="dashboard-feature-icon"><Icon size={21}/></span><h3>{title}</h3><p>{description}</p><span className="dashboard-feature-action">{action}<ArrowLeft size={15}/></span>
       </InertLink>)}</div>
     </section>
     {stats.length > 0 && <section className="dashboard-stats" aria-label="رحلتك حتى الآن"><div className="dashboard-section-heading dashboard-stats-heading"><div><span className="section-kicker">من رحلتك</span><h2>رحلتك حتى الآن</h2></div></div><div className="dashboard-stat-grid">{stats.map(({ value, label, icon: Icon, testId, suffix }) => <div className="dashboard-stat" key={testId}><span className="dashboard-stat-icon"><Icon size={17}/></span><span className="dashboard-stat-copy"><b data-testid={testId}>{value.toLocaleString('ar')}{suffix || ''}</b><small>{label}</small></span></div>)}</div></section>}
    <div className="dashboard-lower">
      <section className="recent-section"><div className="section-heading"><div><span className="section-kicker">من رحلتك</span><h2>أحدث الإنجازات</h2></div><InertLink href="/achievements" className="subtle-link" data-testid="link-all-achievements">كل الإنجازات <ArrowLeft size={15}/></InertLink></div>
        {recent.length ? <div className="achievement-list">{recent.slice(0, 4).map(item => <AchievementCard key={item.id} item={item} compact/>)}</div> : <div className="empty-state" data-testid="status-empty"><span className="empty-mark"><Sparkles size={21}/></span><h3>هنا تبدأ قصتك</h3><p>أضف أول تجربة صنعت فيها فرقاً، مهما كانت صغيرة.</p><InertLink href="/achievements" className="button button-primary button-compact" data-testid="button-empty-add">أضف إنجازك الأول <Plus size={15}/></InertLink></div>}
      </section>
      <aside className="profile-progress-card"><div className="profile-progress-top"><span className="section-kicker">صورتك المهنية</span><span className="progress-percent">{demoProfile ? `${data.profileCompletion}%` : 'ابدأ هنا'}</span></div><h3>ملفك الشخصي</h3><p>أضف تفاصيلك ومهاراتك لتتضح صورتك المهنية.</p><div className="progress-track"><span style={{ width: `${demoProfile ? data.profileCompletion : 0}%` }}/></div><div className="progress-legend"><span>اكتمال الملف</span><b>{data.profileCompletion}%</b></div><InertLink href="/profile" className="progress-cta" data-testid="link-complete-profile">أكمل ملفك <ArrowLeft size={15}/></InertLink><div className="progress-note"><span><Lightbulb size={16}/></span><p>يساعدك الملف المكتمل على رؤية مهاراتك بوضوح.</p></div></aside>
    </div>
  </div>;
}

export function CurrentDashboard() {
  const [isDark, setIsDark] = useState(false);
  return <div className={`athar-current-dashboard${isDark ? ' dark' : ''}`} onClickCapture={(event) => {
    if ((event.target as HTMLElement).closest('a')) event.preventDefault();
  }}>
    <Shell isDark={isDark} toggleTheme={() => setIsDark(value => !value)}><DashboardPage/></Shell>
  </div>;
}
