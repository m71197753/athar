import { useState } from "react";
import { ArrowLeft, BookOpen, Check, Download, ExternalLink, FileText, PlayCircle } from "lucide-react";
import "./_group.css";

type Material = {
  type: "text" | "link" | "media";
  mediaType?: "image" | "video" | "file";
  title: string;
  body: string;
  url: string;
};

const courses = [
  {
    id: "course-data-1",
    title: "كورس تحليل بيانات",
    description: "كورس تحليل بيانات",
    materials: [{ type: "text", title: "مقدمة في تحليل البيانات", body: "ابدأ بالتعرّف إلى خطوات فهم البيانات وتنظيمها.", url: "" }],
  },
  {
    id: "course-data-2",
    title: "كورس تحليل بيانات",
    description: "كورس تحليل بيانات",
    materials: [{ type: "text", title: "تطبيق عملي", body: "تدرّب على قراءة البيانات واستخلاص فكرة واضحة منها.", url: "" }],
  },
] satisfies Array<{ id: string; title: string; description: string; materials: Material[] }>;

function MaterialView({ material }: { material: Material }) {
  if (material.type === "link") {
    return <a className="custom-section-link" href={material.url} target="_blank" rel="noreferrer">
      <span className="custom-section-link-copy"><b>{material.title}</b>{material.body && <span>{material.body}</span>}</span><ExternalLink size={17}/>
    </a>;
  }
  if (material.type === "media") {
    return <section className="custom-section-media">
      <h3>{material.title}</h3>{material.body && <p>{material.body}</p>}
      {material.mediaType === "image" && <img src={material.url} alt={material.title}/>}
      {material.mediaType === "video" && <video src={material.url} controls/>}
      {material.mediaType === "file" && <a href={material.url} download><Download size={16}/> فتح الملف</a>}
    </section>;
  }
  return <section className="custom-section-text"><h3>{material.title}</h3>{material.body && <p>{material.body}</p>}</section>;
}

export function Current() {
  const [completed, setCompleted] = useState<string[]>([]);
  return <main className="athar-course-preview dark" dir="rtl">
    <div className="custom-section-wrap">
      <a className="custom-section-back" href="#"><ArrowLeft size={16}/> العودة لمساحة الطالب</a>
      <header className="custom-section-header">
        <span className="custom-section-kicker"><BookOpen size={15}/> وحدة من أثر</span>
        <h1>كورساتي</h1>
      </header>
      <section className="custom-section-courses">
        <header className="custom-courses-heading">
          <h2>الدورات</h2>
          <p>افتح مواد الدورة، ثم سجّل ما أنجزته في سجل تعلّمك.</p>
        </header>
        <div className="custom-course-list">
          {courses.map((course, index) => {
            const isDone = completed.includes(course.id);
            return <article className={`custom-course-card ${isDone ? "is-completed" : ""}`} key={course.id}>
              <header className="custom-course-card-head">
                <span className="custom-course-number">{String(index + 1).padStart(2, "0")}</span>
                <div className="custom-course-title"><h3>{course.title}</h3><p>{course.description}</p></div>
                {isDone && <span className="custom-course-complete-badge"><Check size={14}/> مكتملة</span>}
              </header>
              <details className="custom-course-details">
                <summary><PlayCircle size={16}/><span>عرض مواد الدورة</span><small>{course.materials.length.toLocaleString("ar")} مواد</small></summary>
                <div className="custom-course-materials">{course.materials.map((material, materialIndex) => <MaterialView key={materialIndex} material={material}/>)}</div>
              </details>
              <footer className="custom-course-actions">
                {isDone ? <span className="custom-course-record"><Check size={16}/> أُضيف إلى سجل إنجازاتك التعليمية</span>
                  : <button className="button button-primary" onClick={() => setCompleted(items => [...items, course.id])}>سجّل إكمال الدورة</button>}
              </footer>
            </article>;
          })}
        </div>
      </section>
    </div>
  </main>;
}
